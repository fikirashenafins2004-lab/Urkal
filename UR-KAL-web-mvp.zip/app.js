const KEY="urkal_data_v1";
const todayISO=()=>new Date().toISOString().slice(0,10);
let data=JSON.parse(localStorage.getItem(KEY)||"null")||{
  promises:[
    {id:1,text:"Study for 45 minutes",date:todayISO(),done:false},
    {id:2,text:"Exercise for 20 minutes",date:todayISO(),done:false},
    {id:3,text:"Read 10 pages",date:todayISO(),done:false}
  ],
  routines:[
    {id:1,name:"Morning routine",done:false},
    {id:2,name:"Study routine",done:false},
    {id:3,name:"Workout routine",done:false},
    {id:4,name:"Sleep routine",done:false}
  ],
  review:{kept:"",broken:"",why:"",tomorrow:""}
};
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function stats(){let p=data.promises.filter(x=>x.date===todayISO());return {total:p.length,done:p.filter(x=>x.done).length}}
function navButton(id,label){return `<button data-page="${id}" class="${page===id?'active':''}">${label}</button>`}
let page="today";
function render(){
 const app=document.querySelector("#app");
 app.innerHTML=`<div class="shell">
  <aside class="sidebar">
   <div class="brand">UR KAL</div><div class="tag">Keep your word.</div>
   <div class="nav">${navButton("today","Today")}${navButton("planner","Planner")}${navButton("routines","Routines")}${navButton("review","Nightly Review")}${navButton("pricing","Pricing")}</div>
   <div style="position:absolute;bottom:25px;font-size:12px;color:#707970">BUILT IN ETHIOPIA · FOR THE WORLD</div>
  </aside>
  <main class="main">${pageView()}</main>
  <nav class="mobile-nav">${navButton("today","Today")}${navButton("planner","Plan")}${navButton("routines","Routines")}${navButton("review","Review")}${navButton("pricing","Pro")}</nav>
 </div>`;
 document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>{page=b.dataset.page;render()});
 wire();
}
function header(kicker,title,sub=""){return `<div class="top"><div><div class="eyebrow">${kicker}</div><div class="title">${title}</div>${sub?`<div class="muted">${sub}</div>`:""}</div></div>`}
function pageView(){
 if(page==="today") return today();
 if(page==="planner") return planner();
 if(page==="routines") return routines();
 if(page==="review") return review();
 return pricing();
}
function today(){
 const s=stats(), pct=s.total?Math.round(s.done/s.total*100):0;
 return `${header("TODAY",new Date().toLocaleDateString(undefined,{weekday:"long",month:"long",day:"numeric"}),"Small promises. Big changes.")}
 <div class="hero"><h2>Keep your word.</h2><p>UR KAL turns your plans into promises. Make them, keep them, and review what happened tonight.</p></div>
 <div class="grid" style="margin-top:16px">
  <div class="card"><div class="muted">Promises kept</div><div class="stat">${s.done}/${s.total}</div><div class="progress"><div style="width:${pct}%"></div></div></div>
  <div class="card"><div class="muted">Today's completion</div><div class="stat">${pct}%</div></div>
  <div class="card"><div class="muted">Streak</div><div class="stat">1 🔥</div></div>
 </div>
 <div class="section-title">Today's promises</div>
 ${data.promises.filter(x=>x.date===todayISO()).map(p=>promiseHTML(p)).join("")||`<div class="card muted">No promises yet. Add one in Planner.</div>`}`;
}
function promiseHTML(p){return `<div class="promise ${p.done?'done':''}"><div><div class="ptext">${esc(p.text)}</div><div class="small">${p.done?"KEPT":"PENDING"}</div></div><div class="actions"><button class="btn ${p.done?'secondary':''}" data-toggle="${p.id}">${p.done?"Undo":"Keep"}</button><button class="btn danger" data-delete="${p.id}">×</button></div></div>`}
function planner(){
 return `${header("PLANNER","Make a promise","Free MVP: up to 5 promises for today.")}
 <div class="card"><div class="form"><input id="promiseInput" class="input" placeholder="What will you keep today?" maxlength="120"><button id="addPromise" class="btn">Add promise</button></div><div class="small">${stats().total}/5 promises used today</div></div>
 <div class="section-title">Today</div>
 ${data.promises.filter(x=>x.date===todayISO()).map(p=>promiseHTML(p)).join("")}`;
}
function routines(){
 return `${header("ROUTINES","Build consistency","Simple routines you can repeat every day.")}
 <div class="card">${data.routines.map(r=>`<div class="routine"><div><strong>${esc(r.name)}</strong><div class="small">${r.done?"Completed today":"Not completed"}</div></div><button class="check" data-routine="${r.id}">${r.done?"✓":""}</button></div>`).join("")}</div>
 <div class="form"><input id="routineInput" class="input" placeholder="New routine"><button id="addRoutine" class="btn">Add</button></div>`;
}
function review(){
 const r=data.review;
 return `${header("NIGHTLY REVIEW","How did you do?","Don't judge the day. Learn from it.")}
 <div class="card review">
 <label class="small">What did you keep?</label><textarea id="kept" class="input">${esc(r.kept)}</textarea>
 <label class="small">What did you break?</label><textarea id="broken" class="input">${esc(r.broken)}</textarea>
 <label class="small">Why?</label><textarea id="why" class="input">${esc(r.why)}</textarea>
 <label class="small">Tomorrow's promise</label><textarea id="tomorrow" class="input">${esc(r.tomorrow)}</textarea>
 <button id="saveReview" class="btn">Save review</button>
 </div>`;
}
function pricing(){
 return `${header("UR KAL PRO","Choose your level","Start free. Upgrade when you need more.")}
 <div class="price-grid">
 <div class="card price"><h3>Free</h3><div class="money">$0</div><ul><li>5 promises/day</li><li>Today + tomorrow planning</li><li>7-day history</li><li>Basic routines</li><li>Nightly review</li></ul><button class="btn secondary">Current plan</button></div>
 <div class="card price pro"><div class="badge">POPULAR</div><h3>Pro</h3><div class="money">$7.99<span class="small">/mo</span></div><ul><li>Unlimited promises</li><li>Unlimited history</li><li>Advanced analytics</li><li>Advanced routines</li><li>AI reviews — coming soon</li></ul><button class="btn" onclick="alert('Payments will be connected here later.')">Choose Pro</button></div>
 <div class="card price"><h3>Business</h3><div class="money">$19.99<span class="small">/mo</span></div><ul><li>Team accountability</li><li>Shared dashboards</li><li>Business analytics</li><li>Admin controls</li><li>Coming soon</li></ul><button class="btn secondary">Coming soon</button></div>
 </div>`;
}
function wire(){
 document.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=()=>{let p=data.promises.find(x=>x.id==b.dataset.toggle);p.done=!p.done;save();render()});
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{data.promises=data.promises.filter(x=>x.id!=b.dataset.delete);save();render()});
 document.querySelectorAll("[data-routine]").forEach(b=>b.onclick=()=>{let r=data.routines.find(x=>x.id==b.dataset.routine);r.done=!r.done;save();render()});
 const add=document.querySelector("#addPromise");
 if(add)add.onclick=()=>{const input=document.querySelector("#promiseInput");const s=stats();if(!input.value.trim())return;if(s.total>=5){alert("Free plan limit: 5 promises per day.");return}data.promises.push({id:Date.now(),text:input.value.trim(),date:todayISO(),done:false});save();render()};
 const ar=document.querySelector("#addRoutine");
 if(ar)ar.onclick=()=>{const i=document.querySelector("#routineInput");if(!i.value.trim())return;data.routines.push({id:Date.now(),name:i.value.trim(),done:false});save();render()};
 const sr=document.querySelector("#saveReview");
 if(sr)sr.onclick=()=>{data.review={kept:document.querySelector("#kept").value,broken:document.querySelector("#broken").value,why:document.querySelector("#why").value,tomorrow:document.querySelector("#tomorrow").value};save();alert("Review saved.");};
}
render();